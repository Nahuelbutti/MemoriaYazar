package com.example.memoriaYazar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var gridLayout: GridLayout
    private var movimientos: Int = 0
    private var ultimosBotonesSeleccionados: MutableList<Button> = mutableListOf()
    private var cartas: MutableList<Int> = mutableListOf(
        1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8
    ).shuffled() as MutableList<Int>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gridLayout = findViewById(R.id.gridLayout)
        gridLayout.columnCount = 4

        val botonReset = findViewById<Button>(R.id.reiniciarButton)
        botonReset.setOnClickListener { reiniciarJuego() }

        for (i in 0 until cartas.size) {
            val boton = Button(this)
            boton.text = ""
            boton.setBackgroundResource(R.drawable.shape)
            boton.setOnClickListener { view ->
                if (ultimosBotonesSeleccionados.size < 2 && boton.text == "") {
                    // Si hay menos de dos botones seleccionados y este botón no ha sido dado vuelta,
                    // se muestra su valor y se agrega a la lista de botones seleccionados
                    boton.text = cartas[i].toString()
                    ultimosBotonesSeleccionados.add(boton)
                }

                if (ultimosBotonesSeleccionados.size == 2) {
                    // Si hay dos botones seleccionados, se verifica si sus valores son iguales
                    movimientos++
                    actualizarMovimientos()
                    val ultimoValor = cartas[cartas.indexOf(ultimosBotonesSeleccionados[1].text.toString().toInt())]
                    val valorActual = cartas[cartas.indexOf(ultimosBotonesSeleccionados[0].text.toString().toInt())]
                    if (ultimoValor == valorActual) {
                        // Si son iguales, los botones quedan visibles y se quitan de la lista de botones seleccionados
                        ultimosBotonesSeleccionados.clear()
                    } else {
                        // Si no son iguales, los botones vuelven a estar ocultos después de un breve
                        // retraso para dar tiempo a visualizarlos
                        val botonUno = ultimosBotonesSeleccionados[0]
                        val botonDos = ultimosBotonesSeleccionados[1]
                        botonUno.postDelayed({
                            botonUno.text = ""
                            botonDos.text = ""
                            ultimosBotonesSeleccionados.clear()
                        }, 500)
                    }
                }
            }
            gridLayout.addView(boton)
        }
    }

    private fun actualizarMovimientos() {
        val textView = findViewById<TextView>(R.id.movimientosTextView)
        textView.text = "Movimientos: $movimientos"
    }

    private fun reiniciarJuego() {
        movimientos = 0
        actualizarMovimientos()
        ultimosBotonesSeleccionados.clear()
        cartas.shuffle()
        for (i in 0 until gridLayout.childCount) {
            val boton = gridLayout.getChildAt(i) as Button
            boton.text = ""
            boton.isClickable = true
        }
    }
}
